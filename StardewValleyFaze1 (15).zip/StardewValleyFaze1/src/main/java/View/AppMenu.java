package View;

import java.util.Scanner;

public abstract class AppMenu {
    public abstract void check(Scanner scanner);
}
