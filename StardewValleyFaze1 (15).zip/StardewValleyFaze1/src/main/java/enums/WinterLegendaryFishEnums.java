package enums;

public enum WinterLegendaryFishEnums
{
    Glacierfish;
}
