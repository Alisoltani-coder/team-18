package enums;

public enum SummerWeatherEnums
{
    Sunny,
    Rain,
    Storm;
}
