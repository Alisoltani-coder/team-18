package enums;

public enum CageAnimalsEnums
{
    Chicken,
    Duck,
    Rabbit,
    Dinosaur,
}
