package enums;

public enum AnimalProductType {
    NORMAL,
    ENHANCED // مثل تخم مرغ بزرگ، پای خرگوش
}
