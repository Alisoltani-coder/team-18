package enums;

public enum FallLegendaryFishEnums
{
    Angler;
}
