package enums;

public enum SummerFishEnums
{
    Tilapia,
    Dorado,
    Sunfish,
    RainbowTrout;
}
