package enums;

public enum SpringFishEnums
{
    Flounder,
    Lionfish,
    Herring,
    Ghostfish;
}
