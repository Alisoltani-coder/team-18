package enums;

public enum SpringLegendaryFishEnums
{
    Legend;
}
