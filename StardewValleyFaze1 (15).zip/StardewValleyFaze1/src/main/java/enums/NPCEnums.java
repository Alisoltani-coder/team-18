package enums;

public enum NPCEnums {
    SEBASTIAN,
    ABIGAIL,
    HARVEY,
    LEAH,
    ROBIN;
}
