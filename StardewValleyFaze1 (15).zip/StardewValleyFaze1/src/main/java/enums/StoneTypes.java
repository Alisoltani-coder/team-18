package enums;

public enum StoneTypes {
    REGULAR,
    COPPER,
    IRON,
    GOLD,
    IRIDIUM;
}
