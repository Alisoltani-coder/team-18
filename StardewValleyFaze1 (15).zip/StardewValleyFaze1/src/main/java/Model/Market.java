package Model;
import Model.Items.*;

import java.util.ArrayList;
import java.util.HashMap;

public class Market
{
protected ArrayList<Item> products;
    public void adaptMap(HashMap<Integer ,Integer> LakeMap)
    {

    }
}
