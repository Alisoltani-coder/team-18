package Model;

public class Quest
{

}
