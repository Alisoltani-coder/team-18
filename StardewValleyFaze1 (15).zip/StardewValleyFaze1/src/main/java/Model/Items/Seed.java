package Model.Items;

public class Seed extends Item {

}
