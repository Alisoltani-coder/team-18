package Model.Items;

public interface Price {
    public int getCorrectPrice();
}
