package Controller;

import Model.App;
import enums.Menu;

public class AvatarMenuController implements MenuEnter, ShowCurrentMenu {

    public void menuEnter(String menuName) {
        //TODO
    }

}
